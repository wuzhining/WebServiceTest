
(function() {
	function kanbanContainerEdit() {	
		
			
	};
	kanbanContainerEdit.prototype = {
		init: function() {
			$(function() {	
				$("td").click(function(){
					$("td").css("border","0px");  //其他td为无色
			 		$(this).css({"border":"1px solid #ccc","box-sizing":"border-box","border-color":"red"}); //点击为红色。
			 		$("#tab3").html('');
			 		$("#tab3").append('<div style="width: 1160px;height:100%;margin-left:-20px;background:url('+'../../../common/IplantCompent/themes/icons/c21.png'+') no-repeat center center ;"></div>');
				});
				
//				//-------------------------------------布局图标点击事件
//				$("#divShowIcron").on("click","img",
//                    function () {
//                        $(this).css("border", "3px solid #E62448");
//                     
//                    });
			});
		}
	}
	var fcfo = new kanbanContainerEdit();
	var warhouseType=[];
	fcfo.init();
})();